<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="UTF-8" isELIgnored ="false"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="stylesheet" crossorigin href="${BASE_FOLDER}vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.jsdelivr.net/gh/wansleynery/SankhyaJX@main/jx.min.js"></script>

    <title>Vite + React + TS</title>
    <script type="module" crossorigin src="${BASE_FOLDER}assets/index-Bo4Ordys.js"></script>
    <link rel="stylesheet" crossorigin href="${BASE_FOLDER}assets/index-DK8tK-8f.css">
    <snk:load/>
    <script>
      window.resolveAsset = (url) => "${BASE_FOLDER}" + url;
    </script>
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>
